# landing-page-bootstrap
Landing page sederhana dengan menggunakan bootstrap. Dibuat dengan melihat tutorial dari channel youtube Web Programming UNPAS dengan judul video NGOBAR#8 : Membuat Website LANDING PAGE menggunakan BOOTSTRAP versi 4.
